package com.project.eratani.features.dataprocess

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.project.eratani.R
import com.project.eratani.core.data.source.local.DummyData
import com.project.eratani.core.ui.adapter.FruitDataAdapter
import com.project.eratani.databinding.FragmentDataProcessBinding
import com.project.eratani.databinding.FragmentSearchBinding

class DataProcessFragment : Fragment() {
    private var _binding: FragmentDataProcessBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDataProcessBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}