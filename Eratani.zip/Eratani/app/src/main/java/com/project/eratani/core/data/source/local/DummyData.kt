package com.project.eratani.core.data.source.local

object DummyData {
    val fruitData = listOf(
        "Apple", "Banana", "Cherry", "Date", "Elderberry",
        "Fig", "Grape", "Honeydew", "Indian Fig", "Jackfruit",
        "Kiwi", "Lemon", "Mango", "Nectarine", "Orange",
        "Papaya", "Quince", "Raspberry", "Strawberry", "Tangerine",
        "Ugli Fruit", "Vanilla", "Watermelon", "Xigua", "Yellow Passion Fruit",
        "Zucchini", "Apricot", "Blackberry", "Cantaloupe", "Dragonfruit"
    )
}