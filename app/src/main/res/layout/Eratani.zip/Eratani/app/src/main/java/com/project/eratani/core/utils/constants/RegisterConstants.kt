package com.project.eratani.core.utils.constants

val listGender = listOf("male", "female")
val listStatusActive = listOf("active", "inactive")