package com.project.eratani.core.utils.constants

const val defaultHeartBeatDuration = 1000